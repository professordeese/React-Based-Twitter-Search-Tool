/*const React = require('react');
const ReactDOM = require('react-dom');
const App = require('./components/App');
//import React from 'react';
//import ReactDOM from 'react-dom';
//import Express from 'express';
//import App from './components/App'

const Express = require('express');


const appExpress = Express();
const portExpress = 3000;



appExpress.get('/', (requestExpress, responseExpress) => responseExpress.send(
    ReactDOM.render(
        <App />,
        document.querySelector('#root')
    )));
appExpress.listen(portExpress, () => console.log(`Example app listening on port ${portExpress}!`));

/*
const Express = require('express');
const appExpress = Express();
const portExpress = 3000;
appExpress.get('/', (requestExpress, responseExpress) => responseExpress.send('Hello World!?!'));
appExpress.listen(portExpress, () => console.log(`Example app listening on port ${portExpress}!`));
////////////////////////////////////////
*/
// index.JS; Anthony S. Deese, Ph.D. www.AnthonyDeese.com
// May 2019

import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App'

ReactDOM.render(
    <App />,
    document.querySelector('#root')
);