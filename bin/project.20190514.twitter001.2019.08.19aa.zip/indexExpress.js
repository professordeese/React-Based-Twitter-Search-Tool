/*const Express = require('express');
const appExpress = Express();
const portExpress = 3000;
appExpress.get('/', (requestExpress, responseExpress) => responseExpress.send('Hello World!?!'));
appExpress.listen(portExpress, () => console.log(`Example app listening on port ${portExpress}!`));*/

const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'reactApp/build')));

app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, 'reactApp/build', 'index.html'));
});

app.listen(8081);